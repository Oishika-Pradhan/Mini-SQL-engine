Run python test.py
